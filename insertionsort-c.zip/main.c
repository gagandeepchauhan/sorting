/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void isort(int[],int);
int main(){
    int i,a[20],n;
    printf("Enter the no. of elements\n");
    scanf("%d",&n);
    printf("Enter %d elements\n",n);
    for(i=1;i<=n;i++)
    	scanf("%d",&a[i]);
    isort(a,n);
    printf("Sorted array is : ");
    for(i=1;i<=n;i++)
    	printf("%d ",a[i]);
    return 0;
}
void isort(int a[],int n){
    int i,j,temp;
    a[0]=-1;
    for(j=1;j<=n;j++){
        i=j-1;
        temp=a[j];
        while(a[i]>a[j]){
            a[i+1]=a[i];
            i--;
            }
        
        a[i+1]=temp;     
    }
}


