/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void quicksort(int[],int,int);
int partition(int[],int,int);
void swap(int *,int *);
int main(){
    int i,a[20],n;
    printf("Enter the no. of elements\n");
    scanf("%d",&n);
    printf("Enter %d elements\n",n);
    for(i=0;i<n;i++)
    	scanf("%d",&a[i]);
    quicksort(a,0,n-1);
    printf("Sorted array is : ");
    for(i=0;i<n;i++)
    	printf("%d ",a[i]);
    return 0;
}
void quicksort(int a[],int p,int r){
	if(p<r){
		int q=partition(a,p,r);
		quicksort(a,p,q-1);
		quicksort(a,q+1,r);
	}
}
int partition(int a[],int p,int r){
	int i,j=p-1,pivot=a[r];
    for(i=p;i<=r;i++){
        if(a[i]<a[r]){
            j++;
        	swap(&a[i],&a[j]);
        }
    }  
    swap(&a[j+1],&a[r]); 
    return j+1;
}
void swap(int *a,int *b){
	int temp=*a;*a=*b;*b=temp;
}

