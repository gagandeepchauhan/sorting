/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
//header files to be included at the top.
void bubble(int[],int);
void swap(int *,int *);
int main(){
    int i,a[20],n;
    printf("Enter the no. of elements\n");
    scanf("%d",&n);
    printf("Enter %d elements\n",n);
    for(i=0;i<n;i++)
    	scanf("%d",&a[i]);
    bubble(a,n);
    printf("Sorted array is : ");
    for(i=0;i<n;i++)
    	printf("%d ",a[i]);
    return 0;
}
void swap(int *a,int *b){
	int temp=*a;*a=*b;*b=temp;
}
void bubble(int a[],int n){
	int i,j;
    for(i=0;i<n;i++){
    	for(j=0;j<n-i-1;j++){
    		if(a[j]>a[j+1])
    			swap(&a[j],&a[j+1]);
    	}
    }
}
