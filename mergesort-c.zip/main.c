/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void merge(int[],int,int,int);
void mergesort(int[],int,int);
int main(){
    int i,a[20],n;
    printf("Enter the no. of elements\n");
    scanf("%d",&n);
    printf("Enter %d elements\n",n);
    for(i=0;i<n;i++)
    	scanf("%d",&a[i]);
    mergesort(a,0,n-1);
    printf("Sorted array is : ");
    for(i=0;i<n;i++)
    	printf("%d ",a[i]);
    return 0;
}
void mergesort(int a[],int p,int r){
	if(p<r){
		int q=(p+r)/2;
		mergesort(a,p,q);
		mergesort(a,q+1,r);
		merge(a,p,q,r);
	}
}
void merge(int a[],int p,int q,int r){
	int n1=q-p+1,n2=r-q,i,j,k;
	int x[n1+1],y[n2+1];
    for(i=0;i<n1;i++)
    	x[i]=a[p+i];
    for(j=0;j<n2;j++)
    	y[j]=a[q+j+1];
    x[n1]=9999;y[n2]=9999;
    i=0;j=0;
    for(k=p;k<=r;k++){
    	if(x[i]<=y[j]){
    		a[k]=x[i];i++;
    	}
    	else{
    		a[k]=y[j];j++;
    	}
    }
}

