/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void swap(float *,float *);
void sort(float [],int [],int []);
void greedy_knapsack(int,float [],int []);
int n;
int main(){
	int p[20],w[20],m,i;
	float x[20],t[20],mp;
	printf("Enter no. of elements : ");
	scanf("%d",&n);
	printf("Enter profits of %d commodity : ",n);
	for(i=1;i<=n;i++)
		scanf("%d",&p[i]);
	printf("Enter weights of %d commodity : ",n);
	for(i=1;i<=n;i++)
		scanf("%d",&w[i]);
	printf("Enter sack Capacity : ");
	scanf("%d",&m);
	for(i=1;i<=n;i++)
		t[i]=(float)p[i]/w[i];
	sort(t,p,w);
	greedy_knapsack(m,x,w);
	printf("The proportion of commodities were : ");
	for(i=1;i<=n;i++){
		mp+=p[i]*x[i];
		printf("%.2f ",x[i]);
	}
	printf("\n Maximum Profit is = %.2f",mp);

	return 0;
}
void greedy_knapsack(int m,float x[],int w[]){
	int i,u=m;
	for(i=1;i<=n;i++)
		x[i]=0;
	for(i=1;i<=n;i++){
		if(w[i]>u)
			break;
		x[i]=1;
		u=u-w[i];
	}
	if(i<=n)
		x[i]=(float)u/w[i];
}
void sort(float t[],int p[],int w[]){
	int i,j;
	for(i=1;i<=n;i++){
		for(j=1;j<=(n-i);j++){
			if(t[j]<t[j+1]){
				swap(&t[j],&t[j+1]);
				swap(&p[j],&p[j+1]);
				swap(&w[j],&w[j+1]);
			}
		}
	}
}
void swap(float *a,float *b){
	float temp=*a;
	*a=*b;
	*b=temp;
}


