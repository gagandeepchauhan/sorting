/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
void selection(int[],int);
int min(int[],int,int);
void swap(int *,int *);
int main(){
    int i,a[20],n;
    printf("Enter the no. of elements\n");
    scanf("%d",&n);
    printf("Enter %d elements\n",n);
    for(i=0;i<n;i++)
    	scanf("%d",&a[i]);
    selection(a,n);
    printf("Sorted array is : ");
    for(i=0;i<n;i++)
    	printf("%d ",a[i]);
    return 0;
}
void selection(int a[],int n){
	int i,loc;
	for(i=0;i<n;i++){
        loc=min(a,i,n-1);
        swap(&a[i],&a[loc]);
	}
}
int min(int a[],int l,int u){
	int loc=l,i,m=a[l];
	for(i=l+1;i<=u;i++){
		if (m>a[i]){
			m=a[i];loc=i;
		}
	}
	return loc;
}
void swap(int *a,int *b){
	int temp=*a;*a=*b;*b=temp;
}